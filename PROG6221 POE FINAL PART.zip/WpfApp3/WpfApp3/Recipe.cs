﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp3
{
    internal class Recipe
    {

        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }

        private List<Ingredient> originalIngredients;

        public event Action<string> OnCaloriesExceeded;

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<Step>();
        }

        public void SaveOriginalIngredients()
        {
            originalIngredients = Ingredients.Select(i => new Ingredient(i.Name, i.Quantity, i.Unit, i.Calories)).ToList();
        }

        public void Scale(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            Ingredients = originalIngredients.Select(i => new Ingredient(i.Name, i.Quantity, i.Unit, i.Calories)).ToList();
        }

        public int TotalCalories()
        {
            int totalCalories = Ingredients.Sum(i => i.Calories);
            if (totalCalories > 300)
            {
                OnCaloriesExceeded?.Invoke($"Warning: Total calories exceed 300! (Total: {totalCalories})");
            }
            return totalCalories;
        }

        public override string ToString()
        {
            return $"{Name}\n\nIngredients:\n{string.Join("\n", Ingredients)}\n\nSteps:\n{string.Join("\n", Steps)}";
        }

        internal void Display()
        {
            throw new NotImplementedException();
        }

        internal void Reset()
        {
            throw new NotImplementedException();
        }
    }
}
