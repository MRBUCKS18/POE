﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            var addRecipe = new AddRecipe();
            addRecipe.ShowDialog();
            RecipeListBox.ItemsSource = recipes.OrderBy(r => r.Name).ToList();
        }

        private void DisplayRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListBox.SelectedItem is Recipe selectedRecipe)
            {
                selectedRecipe.Display();
            }
            else
            {
                MessageBox.Show("Please select a recipe to display.");
            }
        }

        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListBox.SelectedItem is Recipe selectedRecipe)
            {
                var ScaleRecipe = new ScaleRecipe(selectedRecipe);
                ScaleRecipe.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a recipe to scale.");
            }
        }

        private void ResetRecipe_Click(object sender, RoutedEventArgs e)
        {

            if (RecipeListBox.SelectedItem is Recipe selectedRecipe)
            {
                selectedRecipe.Reset();
            }
            else
            {
                MessageBox.Show("Please select a recipe to reset.");
            }
        }

        private void ClearRecipes_Click(object sender, RoutedEventArgs e)
        {

            recipes.Clear();
            RecipeListBox.ItemsSource = null;
            MessageBox.Show("All recipes cleared.");
        }
    }
    }
