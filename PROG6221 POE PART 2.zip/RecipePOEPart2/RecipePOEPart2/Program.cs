﻿using RecipePOEPart2;

internal class Program
{
    static RecipeManager recipeManager = new RecipeManager();

    static void Main(string[] args)
    {
        bool isExiting = false;

        while (!isExiting)
        {
            Console.WriteLine("1. Enter recipe details");
            Console.WriteLine("2. Display recipes");
            Console.WriteLine("3. Choose a recipe to display");
            Console.WriteLine("4. Exit");

            Console.Write("Choose an option: ");
            string input = Console.ReadLine();
            //using switch statement for a user to choose an option
            switch (input)
            {
                case "1":
                    EnterRecipeDetails();
                    break;
                case "2":
                    recipeManager.DisplayRecipes();
                    break;
                case "3":
                    DisplayChosenRecipe();
                    break;
                case "4":
                    isExiting = true;
                    break;
                default:
                    Console.WriteLine("Invalid option please choose the correct option to proceed");
                    break;
            }

            Console.WriteLine();
        }
    }
    //Craeting a method to enter a recipe details
    static void EnterRecipeDetails()
    {
        Console.Write("Enter recipe name: ");
        string name = Console.ReadLine();
        Recipe recipe = new Recipe(name);

        Console.Write("Enter the number of ingredients: ");
        int numIngredients = int.Parse(Console.ReadLine());

        Console.Write("Enter the number of steps: ");
        int numSteps = int.Parse(Console.ReadLine());

        for (int i = 0; i < numIngredients; i++)
        {
            Console.WriteLine($"Enter details for ingredient {i + 1}:");
            Console.Write("Name: ");
            string ingredientName = Console.ReadLine();
            Console.Write("Quantity: ");
            double quantity = double.Parse(Console.ReadLine());
            Console.Write("Unit: ");
            string unit = Console.ReadLine();
            Console.Write("Calories: ");
            int calories = int.Parse(Console.ReadLine());
            Console.Write("Food Group: ");
            string foodGroup = Console.ReadLine();

            recipe.Ingredients.Add(new Ingredient
            {
                Name = ingredientName,
                Quantity = quantity,
                Unit = unit,
                Calories = calories,
                FoodGroup = foodGroup
            });
        }
        //Adding a loop
        for (int i = 0; i < numSteps; i++)
        {
            Console.WriteLine($"Enter step {i + 1}:");
            Console.Write("Description: ");
            string steps = Console.ReadLine();

            recipe.Steps.Add(new Step { Steps = steps });
        }

        recipeManager.AddRecipe(recipe);
        recipeManager.NotifyIfCaloriesExceeded(recipe);
    }
    //Creating a method to display chosen recipe
    static void DisplayChosenRecipe()
    {
        Console.WriteLine("Choose a recipe to display:");
        recipeManager.DisplayRecipes();
        Console.Write("Enter recipe name: ");
        string name = Console.ReadLine();
        Recipe recipe = recipeManager.GetRecipeByName(name);
        if (recipe != null)
        {
            DisplayRecipe(recipe);
        }
        else
        {
            Console.WriteLine("Recipe not found.");
        }
    }
    //method for dispalying recipe
    static void DisplayRecipe(Recipe recipe)
    {
        Console.WriteLine($"Recipe: {recipe.Name}");

        Console.WriteLine("Ingredients:");
        foreach (Ingredient ingredient in recipe.Ingredients)
        {
            Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
        }

        Console.WriteLine("Steps:");
        for (int i = 0; i < recipe.Steps.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {recipe.Steps[i].Steps}");
        }

        int totalCalories = recipe.CalculateTotalCalories();
        Console.WriteLine($"Total Calories: {totalCalories}");

        if (totalCalories > 300)
        {
            Console.WriteLine("Warning: Total calories exceed 300!");
        }
    }
}

