﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipePOEPart2
{
    internal class Step 
    {
        public string Steps { get; set; }
    }
}