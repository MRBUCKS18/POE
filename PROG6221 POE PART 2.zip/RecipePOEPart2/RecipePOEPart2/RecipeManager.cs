﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipePOEPart2
{
    internal class RecipeManager
    {
        public delegate void RecipeCaloriesExceededEventHandler(Recipe recipe);
        public event RecipeCaloriesExceededEventHandler RecipeCaloriesExceeded;

        private List<Recipe> recipes = new List<Recipe>();
        //adding a method to add a recipe
        public void AddRecipe(Recipe recipe)
        {
            recipes.Add(recipe);
        }
        //displaying recipe with a method
        public void DisplayRecipes()
        {
            recipes.Sort((r1, r2) => r1.Name.CompareTo(r2.Name));
            foreach (Recipe recipe in recipes)
            {
                Console.WriteLine(recipe.Name);
            }
        }
        // method to get a recipe by name
        public Recipe GetRecipeByName(string name)
        {
            return recipes.Find(r => r.Name == name);
        }

        public void ScaleRecipe(Recipe recipe, double factor)
        {
            foreach (Ingredient ingredient in recipe.Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void NotifyIfCaloriesExceeded(Recipe recipe)
        {//adding if statement to notify a user if calories are more than 300
            if (recipe.CalculateTotalCalories() > 300)
            {
                RecipeCaloriesExceeded?.Invoke(recipe);
            }
        }
    }
}
